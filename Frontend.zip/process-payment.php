<?php
/**
 * CRIO - Stripe Payment Processor
 * Este archivo procesa los pagos de Stripe
 */

// Configuración de Stripe - REEMPLAZA con tus claves reales en producción
$stripeSecretKey = 'sk_test_51Srljx1Tvl1P8MlhkqcYrsa1qJUUktR02Q56zmLmxBHqAJBzg4kchlwCRBriAUJaV5dsmgerfNDckFKUufxo2A5i00Ia1JyfSG';

// Headers CORS para permitir requests desde tu dominio
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header('Content-Type: application/json');

// Solo permitir POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

// Obtener datos del request
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['error' => 'Datos inválidos']);
    exit;
}

// Validar datos requeridos
$amount = isset($data['amount']) ? floatval($data['amount']) : 0;
$email = isset($data['email']) ? filter_var($data['email'], FILTER_VALIDATE_EMAIL) : false;
$nombre = isset($data['nombre']) ? htmlspecialchars($data['nombre']) : 'Donante';
$description = isset($data['description']) ? htmlspecialchars($data['description']) : 'Donativo CRIO';

if (!$amount || $amount <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Monto inválido']);
    exit;
}

if (!$email) {
    http_response_code(400);
    echo json_encode(['error' => 'Correo electrónico inválido']);
    exit;
}

// Convertir monto a centavos (Stripe trabaja en centavos)
$amountInCents = intval($amount * 100);

// URL de éxito y cancelación - REEMPLAZA con tus URLs reales
$successUrl = 'https://criorizaba.org' . '?donacion=exitosa';
$cancelUrl = 'https://criorizaba.org' . '?donacion=cancelada';

try {

    $ch = curl_init();
    
    curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/checkout/sessions');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'payment_method_types[]' => 'card',
        'line_items[0][price_data][currency]' => 'mxn',
        'line_items[0][price_data][product_data][name]' => $description,
        'line_items[0][price_data][product_data][description]' => 'Donativo de ' . $nombre . ' (' . $email . ')',
        'line_items[0][price_data][unit_amount]' => $amountInCents,
        'line_items[0][quantity]' => 1,
        'mode' => 'payment',
        'success_url' => $successUrl . '&session_id={CHECKOUT_SESSION_ID}',
        'cancel_url' => $cancelUrl,
        'customer_email' => $email,
        'metadata[nombre]' => $nombre,
        'metadata[tipo]' => 'donativo'
    ]));
    curl_setopt($ch, CURLOPT_USERPWD, $stripeSecretKey . ':');
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    $responseData = json_decode($response, true);
    
    if ($httpCode !== 200 || isset($responseData['error'])) {
        throw new Exception($responseData['error']['message'] ?? 'Error al crear la sesión de pago');
    }
    
    // Devolver el session ID al frontend (formato compatible con Stripe.js)
    echo json_encode([
        'success' => true,
        'id' => $responseData['id'],
        'sessionId' => $responseData['id'],
        'url' => $responseData['url']
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => $e->getMessage()
    ]);
}