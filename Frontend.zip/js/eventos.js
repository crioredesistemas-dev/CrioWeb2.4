// JavaScript específico para la sección de Eventos
// Este archivo se ejecuta cuando se carga la sección de eventos

document.addEventListener('DOMContentLoaded', function() {
    // Asegurar que el footer tenga el color correcto
    if (typeof cambiarColorFooter === 'function') {
        cambiarColorFooter('eventos');
    }
    
    // Aquí puedes agregar efectos específicos para la sección de eventos
    console.log('Sección de eventos cargada');
});

