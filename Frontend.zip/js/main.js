// Core front-end interactions: carousel, navigation, puzzles, section loader

const imagenes = [
    'imagenes/fachada/fachada01.jpg',
    'imagenes/fachada/fachada02.jpg',
    'imagenes/fachada/fachada03.jpg'
];

let indiceActual = 0;
let intervaloCarrusel = null;
let contenidoInicial = null;

const imagenesFooter = {
    'inicio': 'imagenes/PiePagina/inicioPie.png',
    'servicios': 'imagenes/PiePagina/serviciosPie.png',
    'terapias': 'imagenes/PiePagina/terapiasPie.png',
    'eventos': 'imagenes/PiePagina/eventosPie.png',
    'historia': 'imagenes/PiePagina/historiaPie.png',
    'donativos': 'imagenes/PiePagina/donacionPie.png'
};

const coloresSeccion = {
    'inicio': 'footer-naranja',
    'servicios': 'footer-azul',
    'terapias': 'footer-lila',
    'eventos': 'footer-rosa',
    'historia': 'footer-amarillo',
    'donativos': 'footer-rojo'
};

function cambiarImagen() {
    const imagenElement = document.getElementById('carousel-image');
    if (!imagenElement) return;
    imagenElement.onload = function() {
        actualizarIndicadores();
        ajustarAlturaContenedor();
    };
    imagenElement.src = imagenes[indiceActual];
    indiceActual = (indiceActual + 1) % imagenes.length;
}

function ajustarAlturaContenedor() {
    const contenedor = document.querySelector('.carousel-container');
    const imagenElement = document.getElementById('carousel-image');
    if (!contenedor || !imagenElement) return;

    // En pantallas móviles, ajustar la altura del contenedor a la altura real de la imagen
    if (window.innerWidth <= 768) {
        const displayedHeight = imagenElement.clientHeight || imagenElement.naturalHeight || 0;
        if (displayedHeight > 0) {
            contenedor.style.height = displayedHeight + 'px';
        } else {
            contenedor.style.height = 'auto';
        }
    } else {
        // En escritorio dejar que CSS controle la altura
        contenedor.style.height = '';
    }
}

function actualizarIndicadores() {
    const indicadores = document.querySelectorAll('.indicator');
    indicadores.forEach((indicator, index) => {
        indicator.classList.remove('active');
        if (index === indiceActual) indicator.classList.add('active');
    });
}

function inicializarCarrusel() {
    cambiarImagen();
    if (intervaloCarrusel) clearInterval(intervaloCarrusel);
    intervaloCarrusel = setInterval(cambiarImagen, 10000);

    // Ajustar contenedor cuando la ventana cambie de tamaño
    window.addEventListener('resize', function() {
        ajustarAlturaContenedor();
    });
}

function detenerCarrusel() {
    if (intervaloCarrusel) {
        clearInterval(intervaloCarrusel);
        intervaloCarrusel = null;
    }
}

function reanudarCarrusel() { inicializarCarrusel(); }

function cambiarimagenesFooter(seccion) {
    const img1 = document.getElementById('footer-bg-1');
    const img2 = document.getElementById('footer-bg-2');
    if (!img1 || !img2) return;
    const imagen = imagenesFooter[seccion] || imagenesFooter['inicio'];
    img1.src = imagen;
    img2.src = imagen;
}

function cambiarColorFooter(seccion) {
    const footer = document.querySelector('.footer');
    const footerTop = document.querySelector('.footer-top');
    const wave = document.querySelector('.footer-wave');
    if (!footer) return;

    // Quitar clases anteriores del footer
    Object.values(coloresSeccion).forEach(clase => footer.classList.remove(clase));

    // Quitar clases anteriores de la barra superior
    const clasesTop = ['footer-naranja', 'footer-azul', 'footer-lila', 'footer-rosa', 'footer-amarillo', 'footer-rojo'];
    clasesTop.forEach(clase => footerTop && footerTop.classList.remove(clase));

    // Quitar clases anteriores de la ola
    clasesTop.forEach(clase => wave && wave.classList.remove(clase));

    // Aplicar nuevas clases
    const claseColor = coloresSeccion[seccion] || 'footer-naranja';
    footer.classList.add(claseColor);
    if (footerTop) footerTop.classList.add(claseColor);
    if (wave) wave.classList.add(claseColor);

    actualizarElementosFooter(seccion);
    cambiarimagenesFooter(seccion);
}

function actualizarElementosFooter(seccion) {
    const coloresTexto = {
        'inicio': '#5a3d1a','servicios': '#1a5276','terapias': '#4a235a',
        'eventos': '#7d1b5e','historia': '#7d6608','donativos': '#922b21'
    };
    const color = coloresTexto[seccion] || coloresTexto['inicio'];
    document.querySelectorAll('.footer-cell h4, .contact-item span, .social-item span, .direccion p')
        .forEach(el => el.style.color = color);
}

function inicializarTitulos() {
    // Establecer estilo compacto para títulos de menú
    document.querySelectorAll('.titulo').forEach(titulo => {
        titulo.style.cssText = 'font-family:Comic,sans-serif;font-size:14px;color:#333;margin-top:8px;display:inline-block;opacity:1;';
    });
}

function agregarEventosBotones() {
    // Use event delegation on the menu container so dynamic changes don't break handlers
    const menuBtns = document.getElementById('menu-buttons');
    if (!menuBtns) return;

    // Remove previous delegated listener if any to avoid duplicates
    if (menuBtns._delegatedClick) menuBtns.removeEventListener('click', menuBtns._delegatedClick);

    const handler = function(e) {
        const boton = e.target.closest('.boton');
        if (!boton || !menuBtns.contains(boton)) return;
        e.preventDefault();
        animarYNavegar(boton, boton.getAttribute('data-seccion'));

        // Close mobile menu if open
        const toggle = document.querySelector('.menu-toggle');
        if (menuBtns.classList.contains('mobile-open')) {
            menuBtns.classList.remove('mobile-open');
            menuBtns.classList.add('mobile-hidden');
            if (toggle) {
                toggle.classList.remove('open');
                toggle.setAttribute('aria-expanded', 'false');
            }
            menuBtns.style.display = 'none';
        }
    };

    menuBtns.addEventListener('click', handler);
    menuBtns._delegatedClick = handler;
}

// Cargar secciones (SPA)
async function cargarSeccion(seccion) {
    const contenedor = document.getElementById('contenido-dinamico');
    if (!contenedor) return;

    if (seccion === 'inicio') {
        if (contenidoInicial) contenedor.innerHTML = contenidoInicial;
        quitarCSSSeccion();
        cambiarColorFooter('inicio');
        window.scrollTo({ top: 0, behavior: 'smooth' });
        setTimeout(() => colocarPiezasRompecabezas(), 100);
        return;
    }

    const ruta = `secciones/${seccion}.html`;
    try {
        contenedor.style.opacity = '0.5';
        contenedor.style.pointerEvents = 'none';

        const respuesta = await fetch(ruta);
        if (!respuesta.ok) throw new Error(`No se pudo cargar: ${ruta}`);
        const html = await respuesta.text();

        const nuevoCont = contenedor.cloneNode(false);
        nuevoCont.id = 'contenido-dinamico';
        contenedor.parentNode.replaceChild(nuevoCont, contenedor);

        nuevoCont.innerHTML = html;
        nuevoCont.style.opacity = '1';
        nuevoCont.style.pointerEvents = 'auto';

        ejecutarScriptsSeccion(nuevoCont);
        cargarCSSSeccion(seccion);
        cambiarColorFooter(seccion);
        window.scrollTo({ top: 0, behavior: 'smooth' });

        setTimeout(() => colocarPiezasRompecabezas(), 100);

    } catch (error) {
        console.error('Error al cargar sección:', error);
        cargarSeccionConXHR(seccion, contenedor);
    }
}

function cargarCSSSeccion(seccion) {
    quitarCSSSeccion();
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = `estilos/${seccion}.css`;
    link.id = 'css-seccion-actual';
    document.head.appendChild(link);
}

function quitarCSSSeccion() {
    const css = document.getElementById('css-seccion-actual');
    if (css) css.remove();
}

function ejecutarScriptsSeccion(contenedor) {
    const scripts = contenedor.querySelectorAll('script');
    scripts.forEach(script => {
        if (script.src) {
            const nuevo = document.createElement('script');
            nuevo.src = script.src;
            document.head.appendChild(nuevo);
        } else if (script.innerHTML.trim()) {
            const nuevo = document.createElement('script');
            nuevo.textContent = script.innerHTML;
            document.head.appendChild(nuevo).remove();
        }
    });
}

function cargarSeccionConXHR(seccion, contenedor) {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', `secciones/${seccion}.html`, true);
    xhr.onload = function() {
        if (xhr.status === 200) {
            contenedor.innerHTML = xhr.responseText;
            contenedor.style.opacity = '1';
            contenedor.style.pointerEvents = 'auto';
            ejecutarScriptsSeccion(contenedor);
            cargarCSSSeccion(seccion);
            cambiarColorFooter(seccion);
            window.scrollTo({ top: 0, behavior: 'smooth' });
        } else {
            mostrarError(seccion, contenedor);
        }
    };
    xhr.onerror = function() { mostrarError(seccion, contenedor); };
    xhr.send();
}

function mostrarError(seccion, contenedor) {
    contenedor.innerHTML = `<div class="error-contenido"><h2>Error al cargar contenido</h2><p>No se pudo cargar la sección: ${seccion}</p></div>`;
    contenedor.style.opacity = '1';
    contenedor.style.pointerEvents = 'auto';
}

function animarYNavegar(elemento, seccion) {
    document.querySelectorAll('.boton').forEach(btn => {
        btn.classList.remove('animacion-rebote', 'boton-activo');
    });
    elemento.classList.add('animacion-rebote', 'boton-activo');
    setTimeout(() => cargarSeccion(seccion), 400);
}

function colocarPiezasRompecabezas() {
    const imagenes = [
        '../imagenes/rompecabezas/rompe1.png',
        '../imagenes/rompecabezas/rompe2.png',
        '../imagenes/rompecabezas/rompe3.png',
        '../imagenes/rompecabezas/rompe4.png'
    ];

    const footer = document.querySelector('.footer');
    let seccionActual = 'inicio';

    if (footer) {
        if (footer.classList.contains('footer-azul')) seccionActual = 'servicios';
        else if (footer.classList.contains('footer-lila')) seccionActual = 'terapias';
        else if (footer.classList.contains('footer-rosa')) seccionActual = 'eventos';
        else if (footer.classList.contains('footer-amarillo')) seccionActual = 'historia';
        else if (footer.classList.contains('footer-rojo')) seccionActual = 'donativos';
    }

    const coloresSeccion = {
        'inicio': '#fef3c7',
        'servicios': '#dbeafe',
        'terapias': '#e9d5ff',
        'eventos': '#fce7f3',
        'historia': '#fef3c7',
        'donativos': '#fee2e2'
    };

    const colorActual = coloresSeccion[seccionActual] || '#000000';
    const margenes = ['margen-izquierdo', 'margen-derecho'];

    margenes.forEach(margenId => {
        const margen = document.getElementById(margenId);
        if (!margen) return;

        let alturaMargen = footer ? footer.offsetTop - 70 :
            Math.max(document.body.scrollHeight, document.documentElement.scrollHeight) - 70;

        margen.style.height = alturaMargen + 'px';
        margen.innerHTML = '';

        const rect = margen.getBoundingClientRect();
        const piezasColocadas = [];
        const tamanoPieza = 60;
        const numPiezas = Math.max(30, Math.floor(alturaMargen / 50));

        for (let i = 0; i < numPiezas; i++) {
            let attempts = 0, placed = false;

            while (attempts < 10 && !placed) {
                const x = Math.random() * (rect.width - tamanoPieza);
                const y = Math.random() * (rect.height - tamanoPieza);
                const piezaRect = { left: x, top: y, right: x + tamanoPieza, bottom: y + tamanoPieza };

                let overlap = piezasColocadas.some(c =>
                    !(piezaRect.right < c.left || piezaRect.left > c.right ||
                      piezaRect.bottom < c.top || piezaRect.top > c.bottom)
                );

                if (!overlap) {
                    const imgSrc = imagenes[Math.floor(Math.random() * imagenes.length)];
                    const pieza = document.createElement('div');
                    pieza.className = 'pieza-rompecabezas';
                    pieza.style.left = x + 'px';
                    pieza.style.top = y + 'px';

                    pieza.style.backgroundColor = colorActual;
                    pieza.style.webkitMaskImage = `url('${imgSrc}')`;
                    pieza.style.maskImage = `url('${imgSrc}')`;
                    pieza.style.webkitMaskSize = 'contain';
                    pieza.style.maskSize = 'contain';
                    pieza.style.webkitMaskRepeat = 'no-repeat';
                    pieza.style.maskRepeat = 'no-repeat';
                    pieza.style.webkitMaskPosition = 'center';
                    pieza.style.maskPosition = 'center';

                    margen.appendChild(pieza);
                    piezasColocadas.push(piezaRect);
                    placed = true;
                }
                attempts++;
            }
        }
    });
}

// INICIALIZACIÓN
document.addEventListener('DOMContentLoaded', function() {
    const cont = document.getElementById('contenido-dinamico');
    if (cont) contenidoInicial = cont.innerHTML;
    inicializarCarrusel();
    inicializarTitulos();
    agregarEventosBotones();
    colocarPiezasRompecabezas();

    const botonInicio = document.querySelector('[data-seccion="inicio"]');
    if (botonInicio) botonInicio.classList.add('boton-activo');
    cambiarColorFooter('inicio');

    // Menú hamburguesa: toggle y accesibilidad
    const menuToggle = document.querySelector('.menu-toggle');
    const menuBtns = document.getElementById('menu-buttons');
    if (menuToggle && menuBtns) {
        // Inicialmente ocultar en móvil
        if (window.innerWidth <= 768) {
            menuBtns.classList.add('mobile-hidden');
        }

        menuToggle.addEventListener('click', function(e) {
            e.stopPropagation();
            const open = menuBtns.classList.contains('mobile-open');
            if (open) {
                menuBtns.classList.remove('mobile-open');
                menuBtns.classList.add('mobile-hidden');
                menuToggle.classList.remove('open');
                menuToggle.setAttribute('aria-expanded', 'false');
            } else {
                menuBtns.classList.remove('mobile-hidden');
                menuBtns.classList.add('mobile-open');
                menuToggle.classList.add('open');
                menuToggle.setAttribute('aria-expanded', 'true');
            }
        });

        // Make sure clicking the toggle itself doesn't close via document click handler immediately
        menuToggle.addEventListener('touchstart', function(e){ e.stopPropagation(); });


        // Cerrar menú si se cambia tamaño de pantalla a escritorio
        window.addEventListener('resize', function() {
            if (window.innerWidth > 768) {
                menuBtns.classList.remove('mobile-hidden', 'mobile-open');
                menuToggle.classList.remove('open');
                menuToggle.setAttribute('aria-expanded', 'false');
                menuBtns.style.display = '';
            } else {
                if (!menuBtns.classList.contains('mobile-open')) menuBtns.classList.add('mobile-hidden');
            }
        });

        // Cerrar al hacer click fuera del menú en móvil
        document.addEventListener('click', function(e) {
            if (window.innerWidth <= 768 && menuBtns.classList.contains('mobile-open')) {
                const target = e.target;
                if (!menuBtns.contains(target) && !menuToggle.contains(target)) {
                    menuBtns.classList.remove('mobile-open');
                    menuBtns.classList.add('mobile-hidden');
                    menuToggle.classList.remove('open');
                    menuToggle.setAttribute('aria-expanded', 'false');
                }
            }
        });

        // Ensure menu toggle buttons propagate click events (fix for blocked pointer-events)
        menuToggle.style.pointerEvents = '';
        menuBtns.style.pointerEvents = '';

    }
});
