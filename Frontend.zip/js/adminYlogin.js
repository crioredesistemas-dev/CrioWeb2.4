// ============================================
// ADMIN & LOGIN - LÓGICA JAVASCRIPT
// ============================================

// ----------------------
// LOGIN
// ----------------------
function initLogin() {
    window.addEventListener('DOMContentLoaded', function() {
        if (localStorage.getItem('jwt_token')) {
            window.location.href = 'admin.html';
        }
    });

    const form = document.getElementById('login-form');
    if (form) {
        form.addEventListener('submit', handleLogin);
    }
}

function handleLogin(e) {
    e.preventDefault();

    const btn = document.getElementById('btn-login');
    const btnText = document.getElementById('btn-text');
    const errorMsg = document.getElementById('error-msg');
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    errorMsg.className = 'error-msg';
    errorMsg.textContent = '';

    btn.disabled = true;
    btnText.innerHTML = '<span class="loading-spinner"></span>Ingresando...';

    fetch(CONFIG.API_URL + '/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    })
    .then(async function(response) {
        if (!response.ok) {
            const text = await response.text();
            throw new Error('Error ' + response.status + ': ' + text);
        }
        return response.json();
    })
    .then(function(data) {
        var payload = data.data || data;
        if (payload.token && payload.user) {
            localStorage.setItem('jwt_token', payload.token);
            localStorage.setItem('usuario', JSON.stringify(payload.user));
            window.location.href = 'admin.html';
        } else {
            throw new Error(data.message || 'Respuesta inválida del servidor');
        }
    })
    .catch(function(err) {
        console.error('Error login:', err);
        btn.disabled = false;
        btnText.textContent = 'Ingresar';
        errorMsg.textContent = '❌ ' + err.message;
        errorMsg.className = 'error-msg show';
    });
}

// ----------------------
// ADMIN PANEL
// ----------------------
let modoEdicion = false;

function initAdmin() {
    if (!localStorage.getItem('jwt_token')) {
        window.location.href = 'login.html';
        return;
    }

    // Cargar eventos al inicio
    cargarEventos();
}

function toggleForm() {
    const form = document.getElementById('form-nuevo');
    if (form.style.display === 'none') {
        form.style.display = 'block';
    } else {
        form.style.display = 'none';
        resetForm();
    }
}

function resetForm() {
            document.getElementById('form-nuevo-evento').reset();
            document.getElementById('id_evento').value = '';
            document.getElementById('imagen').value = '';
            document.getElementById('url_info').value = '';
            document.getElementById('preview-container').classList.remove('active');
            document.getElementById('uploadStatus').className = 'upload-status';
            document.getElementById('btn-submit').textContent = 'Guardar Evento';
            document.getElementById('btn-cancelar-edit').style.display = 'none';
            document.getElementById('btn-cancelar').style.display = 'inline-block';
            modoEdicion = false;
        }

function cancelarEdicion() {
    resetForm();
    toggleForm();
}

async function previewImagen(input) {
    const previewContainer = document.getElementById('preview-container');
    const previewImg = document.getElementById('preview-img');
    const uploadStatus = document.getElementById('uploadStatus');
    const imagenInput = document.getElementById('imagen');

    if (!input.files || !input.files[0]) {
        previewContainer.classList.remove('active');
        imagenInput.value = '';
        return;
    }

    const file = input.files[0];

    if (!file.type.startsWith('image/')) {
        uploadStatus.className = 'upload-status active error';
        uploadStatus.textContent = 'Solo se permiten archivos de imagen';
        return;
    }

    if (file.size > 5 * 1024 * 1024) {
        uploadStatus.className = 'upload-status active error';
        uploadStatus.textContent = 'La imagen no debe superar 5MB';
        return;
    }

    const reader = new FileReader();
    reader.onload = function(e) {
        previewImg.src = e.target.result;
        previewContainer.classList.add('active');
    };
    reader.readAsDataURL(file);

    uploadStatus.className = 'upload-status active loading';
    uploadStatus.textContent = 'Subiendo imagen...';

    const formData = new FormData();
    formData.append('imagen', file);

    try {
        const response = await fetch(CONFIG.API_URL + '/upload', {
            method: 'POST',
            headers: { 'Authorization': 'Bearer ' + localStorage.getItem('jwt_token') },
            body: formData
        });

        const data = await response.json();

        if (data.error === false && data.data && data.data.url) {
            imagenInput.value = data.data.url;
            uploadStatus.className = 'upload-status active success';
            uploadStatus.textContent = 'Imagen subida correctamente';
        } else {
            uploadStatus.className = 'upload-status active error';
            uploadStatus.textContent = 'Error: ' + (data.message || 'Desconocido');
            imagenInput.value = '';
        }
    } catch (err) {
        console.error('Error subiendo imagen:', err);
        uploadStatus.className = 'upload-status active error';
        uploadStatus.textContent = 'Error de conexión';
        imagenInput.value = '';
    }
}

async function guardarEvento(e) {
    e.preventDefault();

    const idEvento = document.getElementById('id_evento').value;
    const imagenUrl = document.getElementById('imagen').value;
    const fileInput = document.getElementById('imagenFile');

    if (fileInput.files && fileInput.files[0] && !imagenUrl) {
        alert('Espera a que la imagen termine de subirse...');
        return;
    }

    const fechaValue = document.getElementById('fecha').value;
    const fechaMySQL = fechaValue ? fechaValue + ' 12:00:00' : null;

            const evento = {
                titulo: document.getElementById('titulo').value,
                descripcion: document.getElementById('descripcion').value,
                fecha: fechaMySQL,
                lugar: document.getElementById('lugar').value,
                estado: document.getElementById('estado').value,
                imagen: imagenUrl || null
            };

            // Incluir url_info explícitamente (null si vacío) y añadir trazas para depuración
            const urlField = document.getElementById('url_info');
            const urlValue = (urlField && urlField.value) ? urlField.value.trim() : null;
            evento.url_info = urlValue;

            console.log('[DEBUG] guardarEvento payload:', evento); // DEBUG: revisar payload en consola

            // Nota: el backend evita sobreescritura si url_info viene como cadena vacía o null según la lógica del controlador
            
    const url = idEvento ? CONFIG.API_URL + '/eventos/' + idEvento : CONFIG.API_URL + '/eventos';
    const method = idEvento ? 'PUT' : 'POST';

    try {
        const r = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + localStorage.getItem('jwt_token')
            },
            body: JSON.stringify(evento)
        });
        const data = await r.json();
        if (data.error === false) {
            alert(idEvento ? 'Evento actualizado exitosamente!' : 'Evento creado exitosamente!');
            resetForm();
            document.getElementById('form-nuevo').style.display = 'none';
            cargarEventos();
        } else {
            alert('Error: ' + (data.message || 'No se pudo guardar el evento'));
        }
    } catch(err) {
        console.error('Error guardando evento:', err);
        alert('Error de conexión: ' + err.message);
    }
}

async function editar(id) {
    try {
        const r = await fetch(CONFIG.API_URL + '/eventos/' + id);
        const data = await r.json();
        if (data.error === false) {
            const e = data.data;
            document.getElementById('id_evento').value = e.id_evento;
            document.getElementById('titulo').value = e.titulo;
            document.getElementById('descripcion').value = e.descripcion;
            document.getElementById('fecha').value = e.fecha.split('T')[0];
            document.getElementById('lugar').value = e.lugar;
                    document.getElementById('estado').value = e.estado;
                    document.getElementById('imagen').value = e.imagen || '';
                    document.getElementById('url_info').value = e.url_info || '';

            const previewContainer = document.getElementById('preview-container');
            const previewImg = document.getElementById('preview-img');
            if (e.imagen) {
                 const backendUrl = CONFIG.API_URL.replace('/api', '');
                 previewImg.src = e.imagen.startsWith('http') ? e.imagen : backendUrl + e.imagen;
                 previewContainer.classList.add('active');
             } else {
                previewContainer.classList.remove('active');
            }

            document.getElementById('uploadStatus').className = 'upload-status';
            document.getElementById('btn-submit').textContent = 'Actualizar Evento';
            document.getElementById('btn-cancelar-edit').style.display = 'inline-block';
            document.getElementById('btn-cancelar').style.display = 'none';
            modoEdicion = true;

            document.getElementById('form-nuevo').style.display = 'block';
            window.scrollTo({ top: 0, behavior: 'smooth' });
        } else {
            alert('No se pudo cargar el evento');
        }
    } catch(err) {
        alert('Error al cargar evento: ' + err.message);
    }
}

function eliminar(id) {
    if (confirm('¿Eliminar este evento?')) {
        fetch(CONFIG.API_URL + '/eventos/' + id, {
            method: 'DELETE',
            headers: { 'Authorization': 'Bearer ' + localStorage.getItem('jwt_token') }
        })
        .then(r => r.json())
        .then(() => cargarEventos());
    }
}

function cargarEventos() {
    const listaEventos = document.getElementById('lista-eventos');
    if (!listaEventos) {
        console.error('No se encontró #lista-eventos');
        return;
    }

    fetch(CONFIG.API_URL + '/eventos')
        .then(r => r.json())
        .then(data => {
            if (data.error === false) {
                let eventos = data.data.eventos;
                // Ordenar por fecha descendente (más recientes primero)
                eventos.sort((a, b) => new Date(b.fecha) - new Date(a.fecha));

                document.getElementById('stat-eventos').textContent = eventos.length;

                if (eventos.length === 0) {
                    listaEventos.innerHTML = '<p style="text-align:center;color:#666;padding:20px;">No hay eventos programados</p>';
                    return;
                }

                const backendUrl = CONFIG.API_URL.replace('/api', '');

                const html = eventos.map(e => {
                    let imagenSrc = '';
                    if (e.imagen) {
                        imagenSrc = e.imagen.startsWith('http') ? e.imagen : backendUrl + e.imagen;
                    }

                    const fechaStr = e.fecha ? e.fecha.split('T')[0] : '';

                    return '<div class="evento-item">' +
                        '<div class="evento-imagen">' +
                            '<img src="' + imagenSrc + '" alt="' + (e.titulo || 'Evento') + '" onerror="this.style.display=\'none\'">' +
                        '</div>' +
                        '<div class="evento-info">' +
                            '<span class="badge">' + (e.estado || 'activo') + '</span>' +
                            '<h3>' + (e.titulo || 'Sin título') + '</h3>' +
                            '<p>' + (e.descripcion || '') + '</p>' +
                            '<p><small>' + fechaStr + ' | ' + (e.lugar || '') + '</small></p>' +
                            '<div style="margin-top:10px">' +
                                '<button class="btn btn-edit" onclick="editar(' + e.id_evento + ')">Editar</button>' +
                                ' ' +
                                '<button class="btn btn-delete" onclick="eliminar(' + e.id_evento + ')">Eliminar</button>' +
                            '</div>' +
                        '</div>' +
                    '</div>';
                }).join('');

                listaEventos.innerHTML = html;
            } else {
                listaEventos.innerHTML = '<p>Error: ' + (data.message || 'No se pudieron cargar los eventos') + '</p>';
            }
        })
        .catch(err => {
            listaEventos.innerHTML = '<p>Error al cargar: ' + err.message + '</p>';
        });
}

function logout() {
    localStorage.removeItem('jwt_token');
    localStorage.removeItem('usuario');
    window.location.href = 'login.html';
}

// Auto-inicialización según la página
document.addEventListener('DOMContentLoaded', function() {
    if (document.body.classList.contains('login-page')) {
        initLogin();
    } else if (document.body.classList.contains('admin-page')) {
        initAdmin();
    }
});
