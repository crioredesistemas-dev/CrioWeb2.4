(function(){
    async function setup() {

    console.log('Timeline cargada - Sistema de notificaciones por CLICK');
    
    // Base de imágenes (usar ruta absoluta para evitar 404 por resolución relativa)
    const IMAGE_BASE = '/imagenes/linea';
const DEFAULT_IMAGE = `${IMAGE_BASE}/default.jpg`;
    
    // 1. PRIMERO: Cargar lista de imágenes y eliminar cualquier tooltip nativo de los puntos
    let imageList = [];
    try {
        const resp = await fetch(`${IMAGE_BASE}/index.json`);
        if (resp.ok) imageList = await resp.json();
    } catch (err) {
        // ignore, fallback to generated list below
    }
    if (!Array.isArray(imageList) || imageList.length === 0) {
        // fallback: generate list of 21 pngs
        imageList = [];
        for (let i = 1; i <= 21; i++) imageList.push(`${IMAGE_BASE}/prueba${i}.png`);
    }

    // Eliminar tooltips nativos
    document.querySelectorAll('.dot').forEach(dot => {
        const t = dot.getAttribute('title');
        if (t) dot.setAttribute('data-info', t);
        dot.removeAttribute('title');
    });
    document.querySelectorAll('.dot').forEach(dot => {
        const t = dot.getAttribute('title');
        if (t) dot.setAttribute('data-info', t);
        dot.removeAttribute('title');
    });
    
    // 2. Crear notificación flotante personalizada
    const notification = document.createElement('div');
    notification.id = 'custom-timeline-notification';
    notification.style.cssText = `
        position: fixed;
        background: #1a1a2e;
        color: white;
        padding: 14px 24px;
        border-radius: 16px;
        font-size: 14px;
        font-family: 'Segoe UI', Arial, sans-serif;
        pointer-events: none;
        z-index: 999999;
        white-space: nowrap;
        box-shadow: 0 10px 25px rgba(0,0,0,0.3);
        transition: opacity 0.25s ease;
        opacity: 0;
        font-weight: 600;
        letter-spacing: 0.3px;
        border-left: 4px solid #f39c12;
        display: none;
    `;
    document.body.appendChild(notification);
    
    let hideTimeout = null;
    
    // Función para mostrar notificación
    function showNotification(message, x, y) {
        if (hideTimeout) clearTimeout(hideTimeout);
        
        notification.textContent = message;
        notification.style.display = 'block';
        notification.style.left = (x - 100) + 'px';
        notification.style.top = (y - 55) + 'px';
        
        // Animación suave
        setTimeout(() => {
            notification.style.opacity = '1';
        }, 10);
        
        // Ocultar después de 3 segundos
        hideTimeout = setTimeout(() => {
            notification.style.opacity = '0';
            setTimeout(() => {
                notification.style.display = 'none';
            }, 250);
        }, 3000);
    }
    
    // 3. Evento CLICK en cada punto
    document.querySelectorAll('.dot').forEach(dot => {
        // Quitar cualquier handler anterior almacenado en el elemento
        if (dot._dotClickHandler) dot.removeEventListener('click', dot._dotClickHandler);
        
        // Crear nuevo handler
        const clickHandler = function(e) {
            e.stopPropagation();
            e.preventDefault();

            let message = '';
            if (this.getAttribute('data-info')) {
                message = this.getAttribute('data-info');
            } else {
                const parent = this.closest('.year-card');
                const year = parent ? parent.querySelector('.year-number')?.innerText : '';
                const color = this.classList.contains('green') ? 'Inicio/Apertura' :
                             this.classList.contains('red') ? 'Reconocimiento' :
                             this.classList.contains('blue') ? 'Expansión' :
                             this.classList.contains('yellow') ? 'Rol Comunitario' :
                             this.classList.contains('pink') ? 'Valores y Enfoques' : 'Evento';
                message = `${year} - ${color}`;
            }

            const rect = this.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const topY = rect.top;

            console.log('Click detectado:', message);
            showNotification(message, centerX, topY);

            const detailImage = document.querySelector('.historia-content img') || document.querySelector('.timeline-image');
            const detailText = document.querySelector('.historia-content .objetivo-text .objetivo-text-inner p') || document.querySelector('.timeline-text') || document.querySelector('.objetivo-text .objetivo-text-inner p');
            if (detailText) detailText.textContent = message;

            const totalImages = imageList.length || 21;
            let imgSrc = null;
            const dataImg = this.getAttribute('data-img') || this.dataset.img;
            if (dataImg) {
                if (/^\d+$/.test(dataImg)) {
                    let idx = parseInt(dataImg, 10);
                    idx = ((idx - 1) % totalImages) + 1;
                    imgSrc = imageList[idx-1] || `${IMAGE_BASE}/prueba${idx}.png`;
                    if (detailImage) detailImage.dataset.currentIndex = idx;
                } else {
                    imgSrc = dataImg.startsWith('http') || dataImg.startsWith('/') ? dataImg : `${IMAGE_BASE}/${dataImg}`;
                }
            } else {
                const allDots = Array.from(document.querySelectorAll('.dot'));
                const dotIndex = allDots.indexOf(this);
                const idx = (dotIndex % totalImages) + 1;
                imgSrc = imageList[idx-1] || `${IMAGE_BASE}/prueba${idx}.png`;
                if (detailImage) detailImage.dataset.currentIndex = idx;
            }

            if (detailImage) {
                // if detailImage currently shows default, keep it until user selects a dot
                // ensure we can cancel previous attempts
                detailImage._loadToken = (detailImage._loadToken || 0) + 1;
                const myToken = detailImage._loadToken;

                // Build candidate list (use imageList which contains pngs)
                const candidates = [];
                if (dataImg) {
                    if (/^\d+$/.test(dataImg)) {
                        let start = ((parseInt(dataImg, 10) - 1) % totalImages) + 1;
                        for (let i = 0; i < totalImages; i++) {
                            const idx = ((start - 1 + i) % totalImages) + 1;
                            candidates.push(imageList[idx-1] || `${IMAGE_BASE}/prueba${idx}.png`);
                        }
                    } else {
                        const resolved = (dataImg.startsWith('http') || dataImg.startsWith('/')) ? dataImg : `${IMAGE_BASE}/${dataImg}`;
                        candidates.push(resolved);
                        for (let i = 1; i <= totalImages; i++) candidates.push(imageList[i-1] || `${IMAGE_BASE}/prueba${i}.png`);
                    }
                } else {
                    // No data-img provided: user clicked a dot without specific image
                    const allDots = Array.from(document.querySelectorAll('.dot'));
                    const dotIndex = allDots.indexOf(this);
                    const start = (dotIndex % totalImages) + 1;
                    for (let i = 0; i < totalImages; i++) {
                        const idx = ((start - 1 + i) % totalImages) + 1;
                        candidates.push(imageList[idx-1] || `${IMAGE_BASE}/prueba${idx}.png`);
                    }
                }

                // visual prep: hide image only during load, keep default visible until a candidate succeeds
                detailImage.style.transition = detailImage.style.transition || 'opacity 0.25s ease';
                // start with opacity 1 (default visible); we will fade out when we have a loaded candidate

                // sequential preload with cancellation token
                let attempt = 0;
                const tryLoad = () => {
                    if (detailImage._loadToken !== myToken) return; // cancelled
                    if (attempt >= candidates.length) {
                        if (detailImage._loadToken !== myToken) return;
                        // final fallback -> keep default image (do nothing)
                        detailImage.dataset.currentIndex = '';
                        return;
                    }

                    const src = candidates[attempt++];
                    const tmp = new Image();
                    tmp.onload = () => {
                        if (detailImage._loadToken !== myToken) return; // cancelled meanwhile
                        // replace visible image only after successful load
                        detailImage.src = src;
                        detailImage.dataset.currentIndex = src.match(/prueba(\d+)\./)?.[1] || '';
                        detailImage.onload = () => { if (detailImage._loadToken === myToken) detailImage.style.opacity = '1'; };
                    };
                    tmp.onerror = () => {
                        if (detailImage._loadToken !== myToken) return;
                        tryLoad();
                    };
                    tmp.src = src;
                };

                tryLoad();
            }
        };
        
        dot.addEventListener('click', clickHandler);
        dot._dotClickHandler = clickHandler;
    });
    
    // 4. Clic fuera para ocultar
    document.addEventListener('click', function(e) {
        if (!e.target.classList || !e.target.classList.contains('dot')) {
            if (hideTimeout) clearTimeout(hideTimeout);
            notification.style.opacity = '0';
            setTimeout(() => {
                if (notification.style.opacity === '0') {
                    notification.style.display = 'none';
                }
            }, 250);
        }
    });
    
    // 5. Efecto hover en años (solo visual, sin tooltips)
    document.querySelectorAll('.year-number').forEach(year => {
        year.addEventListener('click', function() {
            const yearValue = this.parentElement.getAttribute('data-year');
            console.log(`Año seleccionado: ${yearValue}`);
            // Aquí puedes agregar acción
        });
    });
    
    // 6. Eliminar cualquier tooltip CSS que pueda existir
    const style = document.createElement('style');
    style.textContent = `
        .dot:hover::after {
            display: none !important;
            content: none !important;
            visibility: hidden !important;
            opacity: 0 !important;
        }
        .dot {
            overflow: visible !important;
        }
    `;
    document.head.appendChild(style);
    
    // 7. Animación de entrada
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, { threshold: 0.1 });
    
    const timelineSection = document.querySelector('.timeline-section');
    if (timelineSection) {
        timelineSection.style.opacity = '0';
        timelineSection.style.transform = 'translateY(30px)';
        timelineSection.style.transition = 'all 0.6s ease';
        observer.observe(timelineSection);
    }
    
    // 8. Scroll al cargar
    const scrollContainer = document.querySelector('.timeline-scroll');
    if (scrollContainer) {
        setTimeout(() => {
            scrollContainer.scrollLeft = 0;
        }, 100);
    }
    
    console.log('Sistema listo - Haz CLIC en cualquier círculo');
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', setup);
    else setup();
})();