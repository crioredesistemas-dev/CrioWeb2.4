// Módulo para manejar peticiones a la API
const API = {
  baseURL: CONFIG.API_URL,
  token: localStorage.getItem('jwt_token') || null,

  // Configurar headers para peticiones
  getHeaders(includeAuth = true) {
    const headers = {
      'Content-Type': 'application/json'
    };
    
    if (includeAuth && this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }
    
    return headers;
  },

  // Guardar token JWT
  setToken(token) {
    this.token = token;
    localStorage.setItem('jwt_token', token);
  },

  // Eliminar token (logout)
  removeToken() {
    this.token = null;
    localStorage.removeItem('jwt_token');
  },

  // Verificar si está autenticado
  isAuthenticated() {
    return !!this.token;
  },

  // Manejar respuesta de la API
  async handleResponse(response) {
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.message || 'Error en la petición');
    }
    
    return data;
  },

  // GET
  async get(endpoint, includeAuth = false) {
    const response = await fetch(`${this.baseURL}${endpoint}`, {
      method: 'GET',
      headers: this.getHeaders(includeAuth)
    });
    
    return this.handleResponse(response);
  },

  // POST
  async post(endpoint, data, includeAuth = false) {
    const response = await fetch(`${this.baseURL}${endpoint}`, {
      method: 'POST',
      headers: this.getHeaders(includeAuth),
      body: JSON.stringify(data)
    });
    
    return this.handleResponse(response);
  },

  // PUT
  async put(endpoint, data, includeAuth = true) {
    const response = await fetch(`${this.baseURL}${endpoint}`, {
      method: 'PUT',
      headers: this.getHeaders(includeAuth),
      body: JSON.stringify(data)
    });
    
    return this.handleResponse(response);
  },

  // DELETE
  async delete(endpoint, includeAuth = true) {
    const response = await fetch(`${this.baseURL}${endpoint}`, {
      method: 'DELETE',
      headers: this.getHeaders(includeAuth)
    });
    
    return this.handleResponse(response);
  },

  // Login
  async login(username, password) {
    const data = await this.post('/auth/login', { username, password });
    
    if (data.token) {
      this.setToken(data.token);
    }
    
    return data;
  },

  // Logout
  logout() {
    this.removeToken();
  },

  // Verificar token
  async verifyToken() {
    return this.get('/auth/verify', true);
  },

  // Eventos
  async getEventos(params = {}) {
    const query = new URLSearchParams(params).toString();
    return this.get(`/eventos?${query}`);
  },

  async getEventoById(id) {
    return this.get(`/eventos/${id}`);
  },

  async createEvento(evento) {
    return this.post('/eventos', evento, true);
  },

  async updateEvento(id, evento) {
    return this.put(`/eventos/${id}`, evento, true);
  },

  async deleteEvento(id) {
    return this.delete(`/eventos/${id}`, true);
  },

  // Donaciones
  async createDonacion(donacion) {
    return this.post('/donaciones', donacion);
  },

  async getDonaciones(params = {}) {
    const query = new URLSearchParams(params).toString();
    return this.get(`/donaciones?${query}`, true);
  },

  // Pagos
  async procesarPago(pagoData) {
    return this.post('/pagos/procesar', pagoData);
  },

  async confirmarPago(paymentIntentId) {
    return this.post('/pagos/confirmar', { payment_intent_id: paymentIntentId });
  }
};

// Exportar para uso en otros módulos
if (typeof module !== 'undefined' && module.exports) {
  module.exports = API;
}
