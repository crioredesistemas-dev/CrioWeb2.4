// JavaScript específico para la sección de Servicios
// Este archivo se ejecuta cuando se carga la sección de servicios

document.addEventListener('DOMContentLoaded', function() {
    // Asegurar que el footer tenga el color correcto
    if (typeof cambiarColorFooter === 'function') {
        cambiarColorFooter('servicios');
    }
    
    // Aquí puedes agregar efectos específicos para la sección de servicios
    console.log('Sección de servicios cargada');
});

