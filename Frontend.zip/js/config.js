// Configuración global del frontend 
// IMPORTANTE: Actualizar estas URLs al desplegar en producción
const CONFIG = {
  // Detectar automáticamente si estamos en localhost o producción
  API_URL: (typeof window !== 'undefined' && window.location.hostname === 'localhost')
    ? 'http://localhost:3000/api'
    : 'https://api.criorizaba.org/api',

  STRIPE_PUBLISHABLE_KEY: 'pk_test_51Srljx1Tvl1P8MlhANwHn0KVEExvYWFnWZ9xxNJi48A9y0AiD3Rmz0VHgLhEjDhZF5W1A9WYL7DJKlqsXi0beaC400VwiJ6XqY',

  FRONTEND_URL: (typeof window !== 'undefined' && window.location.hostname === 'localhost')
    ? 'http://localhost:5500'
    : 'https://criorizaba.org',

  // Cambiar a true para usar datos mock en desarrollo sin backend
  USE_MOCK: false
};

// Exportar para uso en otros módulos
if (typeof module !== 'undefined' && module.exports) {
  module.exports = CONFIG;
}
