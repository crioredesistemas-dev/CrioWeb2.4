// JavaScript específico para la sección de Terapias
// Este archivo se ejecuta cuando se carga la sección de terapias

document.addEventListener('DOMContentLoaded', function() {
    // Asegurar que el footer tenga el color correcto
    if (typeof cambiarColorFooter === 'function') {
        cambiarColorFooter('terapias');
    }
    
    // Aquí puedes agregar efectos específicos para la sección de terapias
    console.log('Sección de terapias cargada');
});

