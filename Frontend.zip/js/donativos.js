/* donativos.js - lógica modular para la sección Donativos */

(function () {
  'use strict';

  // --- Carousel 3D reutilizable ---
  function initCarousel(scopeSelector = '.videos-carousel') {
    const carousel = document.querySelector(scopeSelector);
    if (!carousel) return;

    const items = Array.from(carousel.querySelectorAll('.carousel-item'));
    if (!items.length) return;

    const n = items.length;
    let offset = 0;
    const radiusX = 280;
    const radiusZ = 300;
    const backZ = -620;
    const centerY = -18;
    let interval = null;
    let isPlayingIndex = -1;
    let userPauseTimeout = null;
    const USER_PAUSE_MS = 3000;
    let autoRotateDirection = -1;

    function render() {
      const frontCount = 3;
      const arc = Math.PI * 0.75;
      const frontAngles = [];
      for (let i = 0; i < frontCount; i++) frontAngles.push(-arc / 2 + (i / (frontCount - 1)) * arc);

      for (let i = 0; i < n; i++) {
        const logical = (i + offset) % n;
        const el = items[i];
        if (logical < frontCount) {
          const angle = frontAngles[logical];
          const x = Math.sin(angle) * radiusX;
          const z = Math.cos(angle) * radiusZ - radiusZ / 2;
          const scale = (logical === 1) ? 1.12 : 0.85;
          const opacity = logical === 1 ? 1 : 0.9;
          const y = centerY;

          el.classList.toggle('center-item', logical === 1);
          el.style.visibility = 'visible';
          el.style.pointerEvents = 'auto';
          el.style.zIndex = 300 + Math.round((z + radiusZ) * 10);
          el.style.opacity = opacity;
          el.style.transform = `translate(-50%, -50%) translate3d(${x}px, ${y}px, ${z}px) scale(${scale})`;
        } else {
          el.classList.remove('center-item');
          el.style.visibility = 'hidden';
          el.style.pointerEvents = 'none';
          el.style.opacity = 0;
          el.style.zIndex = 0;
          el.style.transform = `translate3d(0px, 28px, ${backZ}px) scale(0.78) translate(-50%, -50%)`;
        }
      }
    }

    function startAutoRotate() { stopAutoRotate(); interval = setInterval(() => { offset = (offset + autoRotateDirection + n) % n; render(); }, 2800); }
    function stopAutoRotate() { if (interval) { clearInterval(interval); interval = null; } }

    function pauseForUserInteraction() {
      stopAutoRotate();
      if (userPauseTimeout) clearTimeout(userPauseTimeout);
      userPauseTimeout = setTimeout(() => { userPauseTimeout = null; startAutoRotate(); }, USER_PAUSE_MS);
    }

    window.addEventListener('resize', render);
    setTimeout(() => { render(); startAutoRotate(); }, 120);

    items.forEach((item, idx) => {
      const vid = item.querySelector('video');
      if (vid) {
        vid.addEventListener('ended', function () {
          try { vid.pause(); vid.currentTime = 0; } catch (e) {}
          vid.controls = false;
          isPlayingIndex = -1;
          startAutoRotate();
        });
      }

      item.addEventListener('click', function () {
        const vid = item.querySelector('video');
        if (!vid) return;
        pauseForUserInteraction();

        if (isPlayingIndex !== -1 && isPlayingIndex !== idx) {
          const playingItem = items[isPlayingIndex];
          if (playingItem) {
            const pv = playingItem.querySelector('video');
            if (pv) { try { pv.pause(); pv.currentTime = 0; } catch (e) {} pv.controls = false; }
          }
          isPlayingIndex = -1;
        }

        let logicalPos = (idx + offset) % n;
        if (logicalPos !== 1) {
          const stepsPositive = (1 - logicalPos + n) % n;
          const stepsNegative = (logicalPos - 1 + n) % n;
          autoRotateDirection = stepsPositive <= stepsNegative ? 1 : -1;
          const targetOffset = (1 - idx + n) % n;
          offset = targetOffset;
          render();
          try { vid.pause(); vid.currentTime = 0; } catch (e) {}
          vid.controls = false;
          return;
        }

        if (isPlayingIndex === idx) {
          try { vid.pause(); vid.currentTime = 0; } catch (e) {}
          vid.controls = false;
          isPlayingIndex = -1;
          if (userPauseTimeout) { clearTimeout(userPauseTimeout); userPauseTimeout = null; }
          startAutoRotate();
          return;
        }

        stopAutoRotate();
        if (userPauseTimeout) { clearTimeout(userPauseTimeout); userPauseTimeout = null; }
        items.forEach((it, j) => {
          const v = it.querySelector('video');
          if (v && j !== idx) { try { v.pause(); v.currentTime = 0; } catch (e) {} v.controls = false; }
        });

        vid.controls = true;
        vid.muted = false;
        const p = vid.play(); if (p && p.catch) p.catch(() => {});
        isPlayingIndex = idx;
      });
    });

    // Return API if needed
    return { render, startAutoRotate, stopAutoRotate };
  }

  // --- Selección de montos ---
  function initAmountSelection() {
    function selectAmount(amount) {
      document.querySelectorAll('.amount-card').forEach(c => c.classList.remove('active'));
      const btn = document.querySelector('.amount-card[data-amount="' + amount + '"]');
      if (btn) btn.classList.add('active');
      const input = document.getElementById('donation-amount');
      if (input) input.value = amount;
    }

    document.addEventListener('click', function (e) {
      const btn = e.target.closest('.amount-card');
      if (btn && btn.dataset && btn.dataset.amount) {
        selectAmount(btn.dataset.amount);
      }
    });

    document.addEventListener('DOMContentLoaded', function () { selectAmount(100); });
  }

  // --- Modal helpers ---
  function openVideo(src, title) {
    const modal = document.getElementById('video-modal');
    const body = document.getElementById('video-modal-body');
    if (!modal || !body) return;
    const html = `<h2 style="margin-top:0;">${title || ''}</h2>` +
      `<video controls autoplay style="width:100%;max-height:70vh;border-radius:8px;"><source src="${src}" type="video/mp4">Tu navegador no soporta video.</video>`;
    body.innerHTML = html;
    modal.style.display = 'block';
  }

  function cerrarModal(id) {
    const modal = document.getElementById(id);
    if (!modal) return;
    modal.style.display = 'none';
    const vid = modal.querySelector('video'); if (vid) { vid.pause(); vid.currentTime = 0; }
  }

  function initModalCloseOutside() {
    window.addEventListener('click', function (e) {
      const modal = document.getElementById('video-modal');
      if (modal && e.target === modal) modal.style.display = 'none';
    });
  }

  // --- Inicialización para la sección ---
  function init() {
    initCarousel('.videos-carousel');
    initAmountSelection();
    initModalCloseOutside();

    // Hacer funciones accesibles globalmente si otras partes del sitio las llaman
    window.selectAmount = function (a) { document.querySelectorAll('.amount-card').forEach(c => c.classList.remove('active')); const btn = document.querySelector('.amount-card[data-amount="' + a + '"]'); if (btn) btn.classList.add('active'); const input = document.getElementById('donation-amount'); if (input) input.value = a; };
    window.openVideo = openVideo;
    window.cerrarModal = cerrarModal;

    // --- Checkout (Stripe Checkout Session) ---
    async function startCheckout() {
      const amountInput = document.getElementById('donation-amount');
      const amount = Number(amountInput ? amountInput.value : 100);

       try {
         // Llamar al backend real (Node) que maneja Stripe en modo test
         const apiBase = (typeof CONFIG !== 'undefined' && CONFIG.API_URL) ? CONFIG.API_URL : 'http://localhost:3000';
         console.log('API Base:', apiBase);
         const res = await fetch(`${apiBase}/stripe/create-checkout-session`, {
           method: 'POST',
           headers: { 'Content-Type': 'application/json' },
           body: JSON.stringify({ amount })
         });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Error creando sesión');

        const sessionId = data.id || data.sessionId;
        if (!sessionId) throw new Error('No se recibió session ID');

        // Stripe.js ya cargado en el HTML
        const stripeKey = (typeof CONFIG !== 'undefined' && CONFIG.STRIPE_PUBLISHABLE_KEY) ? CONFIG.STRIPE_PUBLISHABLE_KEY : window.STRIPE_PUBLISHABLE_KEY;
        const stripe = Stripe(stripeKey);
        const { error } = await stripe.redirectToCheckout({ sessionId });
        if (error) console.error('Stripe redirect error', error);
      } catch (err) {
        console.error('Checkout error', err);
        alert('No se pudo iniciar el pago. Revisa la consola.');
      }
    }

    // Asignar evento al botón DONAR
    document.addEventListener('click', function (e) {
      if (e.target && e.target.matches('.btn-action')) {
        e.preventDefault();
        startCheckout();
      }
    });
  }

  // Ejecutar init cuando el DOM de la sección esté listo
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();

})();
