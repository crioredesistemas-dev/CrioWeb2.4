// Chatbot CRIITO - Asistente virtual del CRIO
// Basado en reglas simples

const ChatBot = {
    nombre: 'CRIITO',
    esAbierto: false,
    
    respuestas: {
        'hola': 'Hola! Soy CRIITO, el asistente virtual del CRIO. En que puedo ayudarte?',
        'que es el crio': 'El CRIO es un centro especializado en rehabilitacion para personas con discapacidad neuromuscularoesqueletica.',
        'mision': 'Nuestra mision es brindar amor, apoyo a la integracion social y respeto a las personas con capacidades diferentes.',
        'vision': 'Nuestra vision es contribuir a la integracion total de las personas con capacidades diferentes.',
        'servicios': 'Ofrecemos: Terapia Fisica, Terapia Ocupacional, Terapia de Lenguaje, Traumatologia y mas.',
        'terapias': 'Contamos con terapias personalizadas: Fisica, Ocupacional, Lenguaje y mas.',
        'donaciones': 'Puedes donar desde nuestra seccion Donativos. Aceptamos pagos via Stripe. Tu apoyo nos ayuda mucho!',
        'donar': 'Ve a la seccion Donativos en el menu. Puedes donar montos predefinidos o personalizados.',
        'eventos': 'Consulta nuestra seccion de Eventos para ver proximas actividades y talleres.',
        'ubicacion': 'Estamos en: Prof. de Colon Ote. Num. Lt. 1, Col. Agricola Moctezuma, Orizaba, Ver.',
        'telefono': 'Llamanos al: 272 106 3003 o WhatsApp: 272 198 4051',
        'horario': 'Lunes a viernes 8:00 AM a 6:00 PM, sabados 9:00 AM a 2:00 PM.',
        'citas': 'Para citas llamanos al 272 106 3003 o WhatsApp 272 198 4051.',
        'contacto': 'Tel: 272 106 3003, WhatsApp: 272 198 4051, o visitanos en Orizaba, Ver.',
        'valores': 'Nuestros valores: Amor, Respeto, Responsabilidad, Compromiso, Calidad, Sensibilidad.',
        'gracias': 'Gracias a ti! Estamos aqui para servirte.',
        'adios': 'Hasta luego! Si necesitas mas informacion, consultame. Que tengas un excelente dia.'
    },
    
    respuestasDefault: [
        'No entendi tu pregunta. Puedes preguntar sobre: servicios, terapias, donaciones, ubicacion.',
        'Disculpa, no comprendo. Puedo ayudarte con informacion sobre nuestros servicios o ubicacion.',
        'No estoy seguro de entender. Quieres saber sobre servicios, horarios o como donar?'
    ],
    
    init() {
        this.crearInterfaz();
        this.configurarEventos();
    },
    
    crearInterfaz() {
        if (document.getElementById('chatbot-container')) return;
        
        const html = `
            <div id="chatbot-container" class="chatbot-container">
                <div id="chatbot-toggle" class="chatbot-toggle">
                    <span class="chatbot-icon">💜</span>
                    <span class="chatbot-label">CRIITO</span>
                </div>
                <div id="chatbot-window" class="chatbot-window" style="display: none;">
                    <div class="chatbot-header">
                        <div class="chatbot-header-info">
                            <span class="chatbot-avatar">🤖</span>
                            <div>
                                <h4>CRIITO</h4>
                                <span class="chatbot-status">Asistente Virtual</span>
                            </div>
                        </div>
                        <button id="chatbot-close" class="chatbot-close">✕</button>
                    </div>
                    <div id="chatbot-messages" class="chatbot-messages">
                        <div class="chatbot-message bot">
                            <div class="message-content">
                                Hola! Soy <strong>CRIITO</strong>, tu asistente virtual. En que puedo ayudarte?
                            </div>
                        </div>
                    </div>
                    <div class="chatbot-input-container">
                        <input type="text" id="chatbot-input" class="chatbot-input" placeholder="Escribe tu pregunta...">
                        <button id="chatbot-send" class="chatbot-send">Enviar</button>
                    </div>
                    <div class="chatbot-suggestions">
                        <button class="suggestion-btn" data-query="servicios">Servicios</button>
                        <button class="suggestion-btn" data-query="donaciones">Donaciones</button>
                        <button class="suggestion-btn" data-query="ubicacion">Ubicacion</button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', html);
    },
    
    configurarEventos() {
        const toggle = document.getElementById('chatbot-toggle');
        const close = document.getElementById('chatbot-close');
        const input = document.getElementById('chatbot-input');
        const send = document.getElementById('chatbot-send');
        const suggestions = document.querySelectorAll('.suggestion-btn');
        
        if (toggle) toggle.addEventListener('click', () => this.toggleChat());
        if (close) close.addEventListener('click', () => this.toggleChat());
        if (send) send.addEventListener('click', () => this.procesarMensaje());
        if (input) {
            input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') this.procesarMensaje();
            });
        }
        if (suggestions) {
            suggestions.forEach(btn => {
                btn.addEventListener('click', () => {
                    input.value = btn.getAttribute('data-query');
                    this.procesarMensaje();
                });
            });
        }
    },
    
    toggleChat() {
        const window = document.getElementById('chatbot-window');
        if (window) {
            const isVisible = window.style.display !== 'none';
            window.style.display = isVisible ? 'none' : 'block';
            this.esAbierto = !isVisible;
            if (this.esAbierto && document.getElementById('chatbot-input')) {
                document.getElementById('chatbot-input').focus();
            }
        }
    },
    
    procesarMensaje() {
        const input = document.getElementById('chatbot-input');
        const mensaje = input.value.trim();
        if (!mensaje) return;
        
        this.agregarMensaje(mensaje, 'user');
        input.value = '';
        
        setTimeout(() => {
            const respuesta = this.obtenerRespuesta(mensaje);
            this.agregarMensaje(respuesta, 'bot');
        }, 500);
    },
    
    obtenerRespuesta(mensaje) {
        const msg = mensaje.toLowerCase();
        
        for (const [palabra, respuesta] of Object.entries(this.respuestas)) {
            if (msg.includes(palabra)) {
                return respuesta;
            }
        }
        
        if (msg.match(/horari|abierto|cerrado/)) return this.respuestas['horario'];
        if (msg.match(/cita|agendar/)) return this.respuestas['citas'];
        if (msg.match(/gracias/)) return this.respuestas['gracias'];
        if (msg.match(/adios|bye|hasta/)) return this.respuestas['adios'];
        if (msg.match(/hola|buenos/)) return this.respuestas['hola'];
        
        const randomIndex = Math.floor(Math.random() * this.respuestasDefault.length);
        return this.respuestasDefault[randomIndex];
    },
    
    agregarMensaje(texto, tipo) {
        const messagesContainer = document.getElementById('chatbot-messages');
        if (!messagesContainer) return;
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `chatbot-message ${tipo}`;
        messageDiv.innerHTML = `<div class="message-content">${texto}</div>`;
        
        messagesContainer.appendChild(messageDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
};

document.addEventListener('DOMContentLoaded', () => {
    ChatBot.init();
});

if (typeof module !== 'undefined' && module.exports) {
    module.exports = ChatBot;
}
