-- Script de inicialización de base de datos para CRIO
-- Centro de Rehabilitación Integral de Orizaba A.C.

-- Crear base de datos si no existe
CREATE DATABASE IF NOT EXISTS crio_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE crio_db;

-- ============================================
-- TABLA: usuarios_admin
-- ============================================
CREATE TABLE IF NOT EXISTS usuarios_admin (
    id_usuario INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    rol ENUM('admin', 'editor') DEFAULT 'editor',
    activo BOOLEAN DEFAULT TRUE,
    ultimo_acceso DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLA: eventos
-- ============================================
CREATE TABLE IF NOT EXISTS eventos (
    id_evento INT PRIMARY KEY AUTO_INCREMENT,
    titulo VARCHAR(200) NOT NULL,
    descripcion TEXT,
    fecha DATETIME NOT NULL,
    fecha_fin DATETIME NULL,
    lugar VARCHAR(200),
    imagen VARCHAR(500),
    estado ENUM('activo', 'cancelado', 'finalizado') DEFAULT 'activo',
    id_usuario INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES usuarios_admin(id_usuario) ON DELETE RESTRICT,
    INDEX idx_fecha (fecha),
    INDEX idx_estado (estado),
    INDEX idx_usuario (id_usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLA: donaciones
-- ============================================
CREATE TABLE IF NOT EXISTS donaciones (
    id_donacion INT PRIMARY KEY AUTO_INCREMENT,
    monto DECIMAL(10,2) NOT NULL,
    fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    metodo_pago ENUM('stripe', 'paypal', 'transferencia', 'efectivo') NOT NULL,
    estado ENUM('pendiente', 'completada', 'fallida', 'reembolsada') DEFAULT 'pendiente',
    id_usuario INT NULL,
    nombre_donante VARCHAR(100),
    email_donante VARCHAR(100),
    telefono VARCHAR(20),
    anonimo BOOLEAN DEFAULT FALSE,
    recurrente BOOLEAN DEFAULT FALSE,
    frecuencia ENUM('mensual', 'trimestral', 'anual') NULL,
    notas TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES usuarios_admin(id_usuario) ON DELETE SET NULL,
    INDEX idx_fecha (fecha),
    INDEX idx_estado (estado),
    INDEX idx_metodo_pago (metodo_pago)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLA: pagos
-- ============================================
CREATE TABLE IF NOT EXISTS pagos (
    id_pago INT PRIMARY KEY AUTO_INCREMENT,
    referencia_ext VARCHAR(100) NOT NULL,
    proveedor ENUM('stripe', 'paypal') NOT NULL,
    estado ENUM('pendiente', 'completado', 'fallido', 'reembolsado') DEFAULT 'pendiente',
    monto DECIMAL(10,2) NOT NULL,
    moneda VARCHAR(3) DEFAULT 'MXN',
    fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    id_donacion INT NOT NULL,
    datos_adicionales JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (id_donacion) REFERENCES donaciones(id_donacion) ON DELETE CASCADE,
    INDEX idx_referencia (referencia_ext),
    INDEX idx_proveedor (proveedor),
    INDEX idx_estado (estado),
    INDEX idx_donacion (id_donacion)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- DATOS INICIALES
-- ============================================

-- Usuario administrador por defecto (password: CRIO_2026!)
-- El hash es: $2a$10$fRuSbiQ2BoQyBKcQ57np.O8vocnxXGdaDPiINg5ujPxIGKQ7ZulNe
-- IMPORTANTE: Cambiar el password en producción
INSERT INTO usuarios_admin (username, password, nombre, email, rol) VALUES
('admin', '$2a$10$fRuSbiQ2BoQyBKcQ57np.O8vocnxXGdaDPiINg5ujPxIGKQ7ZulNe', 'Administrador CRIO', 'admin@crio.org.mx', 'admin');

-- Eventos de ejemplo
INSERT INTO eventos (titulo, descripcion, fecha, fecha_fin, lugar, imagen, estado, id_usuario) VALUES
('Caminata por la Rehabilitación', 'Acompáñanos en nuestra caminata anual para promover la rehabilitación integral.', '2024-11-15 08:00:00', '2024-11-15 12:00:00', 'Parque Castillo', '/imagenes/eventos/caminata.jpg', 'activo', 1),
('Taller de Terapia Física', 'Aprende técnicas básicas de terapia física para el cuidado en casa.', '2024-12-01 10:00:00', '2024-12-01 14:00:00', 'CRIO - Salón Principal', '/imagenes/eventos/taller.jpg', 'activo', 1),
('Campaña de Donación de Sangre', 'Colabora con nuestra campaña de donación de sangre. Tu ayuda salva vidas.', '2024-12-10 09:00:00', '2024-12-10 15:00:00', 'Instalaciones CRIO', '/imagenes/eventos/sangre.jpg', 'activo', 1);

-- ============================================
-- VISTAS ÚTILES
-- ============================================

-- Vista para reporte de donaciones con información de pagos
CREATE OR REPLACE VIEW vw_donaciones_completas AS
SELECT 
    d.id_donacion,
    d.monto,
    d.fecha,
    d.metodo_pago,
    d.estado AS estado_donacion,
    d.nombre_donante,
    d.email_donante,
    d.anonimo,
    d.recurrente,
    p.referencia_ext,
    p.proveedor,
    p.estado AS estado_pago,
    u.username AS usuario_registro
FROM donaciones d
LEFT JOIN pagos p ON d.id_donacion = p.id_donacion
LEFT JOIN usuarios_admin u ON d.id_usuario = u.id_usuario;

-- ============================================
-- PROCEDIMIENTOS ALMACENADOS (OPCIONAL)
-- ============================================

DELIMITER //

-- Procedimiento para obtener estadísticas de donaciones
CREATE PROCEDURE sp_estadisticas_donaciones(IN fecha_inicio DATE, IN fecha_fin DATE)
BEGIN
    SELECT 
        COUNT(*) AS total_donaciones,
        SUM(monto) AS monto_total,
        AVG(monto) AS monto_promedio,
        metodo_pago,
        estado
    FROM donaciones
    WHERE DATE(fecha) BETWEEN fecha_inicio AND fecha_fin
    GROUP BY metodo_pago, estado;
END //

DELIMITER ;

-- ============================================
-- TRIGGERS (OPCIONAL)
-- ============================================

DELIMITER //

-- Trigger para actualizar estado de donación cuando se completa un pago
CREATE TRIGGER tr_pago_completado
AFTER UPDATE ON pagos
FOR EACH ROW
BEGIN
    IF NEW.estado = 'completado' AND OLD.estado != 'completado' THEN
        UPDATE donaciones 
        SET estado = 'completada' 
        WHERE id_donacion = NEW.id_donacion;
    END IF;
END //

DELIMITER ;

-- ============================================
-- ÍNDICES ADICIONALES PARA OPTIMIZACIÓN
-- ============================================

CREATE INDEX idx_donaciones_fecha_estado ON donaciones(fecha, estado);
CREATE INDEX idx_pagos_fecha_proveedor ON pagos(fecha, proveedor);

-- Script completado
SELECT 'Base de datos CRIO inicializada correctamente' AS mensaje;
