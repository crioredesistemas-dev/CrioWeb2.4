// Script de prueba para verificar conexión a base de datos
const { pool } = require('./src/config/db');

async function testDB() {
    console.log('🔍 Probando conexión a base de datos CRIO...');
    
    try {
        const [rows] = await pool.query('SELECT VERSION() as version');
        console.log('✅ Conexión exitosa!');
        console.log(`   MySQL version: ${rows[0].version}`);
        
        const [tables] = await pool.query('SHOW TABLES');
        console.log(`   ✅ Tablas encontradas: ${tables.length}`);
        tables.forEach(table => {
            const tableName = Object.values(table)[0];
            console.log(`      - ${tableName}`);
        });
        
        // Verificar datos
        const [eventos] = await pool.query('SELECT COUNT(*) as total FROM eventos');
        console.log(`   📅 Eventos registrados: ${eventos[0].total}`);
        
        const [usuarios] = await pool.query('SELECT COUNT(*) as total FROM usuarios_admin');
        console.log(`   👥 Usuarios admin: ${usuarios[0].total}`);
        
        console.log('\n✅ Base de datos lista!');
        process.exit(0);
        
    } catch (error) {
        console.error('❌ Error:', error.message);
        console.log('\nSugerencias:');
        console.log('1. Verifica que MySQL esté corriendo: sudo service mysql status');
        console.log('2. Verifica credenciales en .env');
        console.log('3. Ejecuta: mysql -u root -p < database/init.sql');
        process.exit(1);
    } finally {
        await pool.end();
    }
}

testDB();
