// Almacenamiento temporal de eventos (en memoria)
let eventos = [
  {
    id_evento: 3,
    titulo: 'Campaña de Donación de Sangre',
    descripcion: 'Colabora con nuestra campaña de donación de sangre. Tu ayuda salva vidas.',
    fecha: '2024-12-10T15:00:00.000Z',
    fecha_fin: '2024-12-10T21:00:00.000Z',
    lugar: 'Instalaciones CRIO',
    imagen: '/imagenes/eventos/sangre.jpg',
    estado: 'activo',
    id_usuario: 1,
    created_at: '2026-04-25T03:30:14.000Z',
    updated_at: '2026-04-25T03:30:14.000Z'
  },
  {
    id_evento: 2,
    titulo: 'Taller de Terapia Física',
    descripcion: 'Aprende técnicas básicas de terapia física para el cuidado en casa.',
    fecha: '2024-12-01T16:00:00.000Z',
    fecha_fin: '2024-12-01T20:00:00.000Z',
    lugar: 'CRIO - Salón Principal',
    imagen: '/imagenes/eventos/taller.jpg',
    estado: 'activo',
    id_usuario: 1,
    created_at: '2026-04-25T03:30:14.000Z',
    updated_at: '2026-04-25T03:30:14.000Z'
  },
  {
    id_evento: 1,
    titulo: 'Caminata por la Rehabilitación',
    descripcion: 'Acompáñanos en nuestra caminata anual para promover la rehabilitación integral.',
    fecha: '2024-11-15T14:00:00.000Z',
    fecha_fin: '2024-11-15T18:00:00.000Z',
    lugar: 'Parque Castillo',
    imagen: '/imagenes/eventos/caminata.jpg',
    estado: 'activo',
    id_usuario: 1,
    created_at: '2026-04-25T03:30:14.000Z',
    updated_at: '2026-04-25T03:30:14.000Z'
  }
];

module.exports = eventos;
