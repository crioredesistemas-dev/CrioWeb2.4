#!/bin/bash
while true; do
   echo "Iniciando backend..."
   DB_HOST=127.0.0.1 DB_PORT=3306 DB_USER=crio_user DB_PASSWORD=crio_pass_2024 DB_NAME=crio_db NODE_ENV=development node server.js
  echo "Backend caído, reiniciando en 3 segundos..."
  sleep 3
done
