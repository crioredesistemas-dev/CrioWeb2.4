require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const xssClean = require('xss-clean');
const mongoSanitize = require('express-mongo-sanitize');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Importar rutas
const authRoutes = require('./src/routes/auth.routes');
const eventosRoutes = require('./src/routes/eventos.routes');
const donacionesRoutes = require('./src/routes/donaciones.routes');
const pagosRoutes = require('./src/routes/pagos.routes');
const stripeRoutes = require('./src/routes/stripe.routes');

const app = express();
const PORT = process.env.PORT || 3000;

// ============================================
// CONFIGURACIÓN DE SUBIDA DE IMÁGENES
// ============================================
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configurar multer para guardar imágenes
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadsDir);
  },
  filename: function (req, file, cb) {
    // Nombre único: fecha + nombre original
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    cb(null, 'evento-' + uniqueSuffix + ext);
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB límite
  },
  fileFilter: function (req, file, cb) {
    // Solo permitir imágenes
    const filetypes = /jpeg|jpg|png|gif/;
    const mimetype = filetypes.test(file.mimetype);
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    
    if (mimetype && extname) {
      return cb(null, true);
    }
    cb(new Error('Solo se permiten archivos de imagen (jpg, jpeg, png, gif)'));
  }
});

// ============================================
// MIDDLEWARES DE SEGURIDAD
// ============================================
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      scriptSrc: ["'self'", "'unsafe-inline'", "https://js.stripe.com"],
      frameSrc: ["'self'", "https://js.stripe.com"],
      imgSrc: ["'self'", "data:", "https:", "http:"],
    },
  },
  crossOriginResourcePolicy: false
}));

app.use(cors({
  origin: '*', // For debugging CORS; replace with specific origin in production
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));
app.use(xssClean());
app.use(mongoSanitize());

// Servir archivos estáticos (imágenes subidas) con CORS
app.use('/uploads', (req, res, next) => {
  res.header('Access-Control-Allow-Origin', process.env.FRONTEND_URL || 'http://localhost:5500');
  res.header('Access-Control-Allow-Methods', 'GET');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  next();
}, express.static(uploadsDir));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: 'Demasiadas solicitudes desde esta IP, intente más tarde.'
});
app.use('/api/', limiter);

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: 'Demasiados intentos de inicio de sesión, intente más tarde.'
});

// ============================================
// RUTAS
// ============================================
app.get('/', (req, res) => {
  res.json({
    message: 'API CRIO - Centro de Rehabilitación Integral de Orizaba A.C.',
    version: '1.0.0',
    status: 'running'
  });
});

app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ============================================
// RUTAS MOCK
// ============================================
app.options('*', cors());

// ============================================
// SUBIDA DE IMÁGENES
// ============================================
app.post('/api/upload', upload.single('imagen'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ 
      error: true, 
      message: 'No se proporcionó ninguna imagen' 
    });
  }
  
  // Devolver URL de la imagen subida
  const imageUrl = `/uploads/${req.file.filename}`;
  
  res.json({
    error: false,
    message: 'Imagen subida exitosamente',
    data: {
      filename: req.file.filename,
      originalname: req.file.originalname,
      mimetype: req.file.mimetype,
      size: req.file.size,
      url: imageUrl,
      fullUrl: `${req.protocol}://${req.get('host')}${imageUrl}`
    }
  });
});

// ============================================
// RUTAS DE LA API
// ============================================
app.use('/api/auth', authRoutes);
app.use('/api/eventos', eventosRoutes);
app.use('/api/donaciones', donacionesRoutes);
app.use('/api/pagos', pagosRoutes);
app.use('/api/stripe', stripeRoutes);

// Manejo de errores
app.use((err, req, res, next) => {
  console.error(err.stack);
  
  if (err instanceof multer.MulterError) {
    return res.status(400).json({ 
      error: true, 
      message: 'Error al subir archivo: ' + err.message 
    });
  }
  
  if (err.message.includes('imagen')) {
    return res.status(400).json({ 
      error: true, 
      message: err.message 
    });
  }
  
  res.status(err.status || 500).json({
    error: true,
    message: err.message || 'Error interno del servidor'
  });
});

// Iniciar servidor
const { testConnectionRetry } = require('./src/config/db');

const startServer = async () => {
  const dbOk = await testConnectionRetry();
  if (!dbOk) {
    console.error('❌ No se pudo conectar a la base de datos. Servidor NO iniciado.');
    process.exit(1);
  }

  app.listen(PORT, () => {
    console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
    console.log(`📝 Ambiente: ${process.env.NODE_ENV || 'development'}`);
    console.log(`🖼️  Subida de imágenes: http://localhost:${PORT}/uploads/`);
  });
};

startServer();

module.exports = app;
