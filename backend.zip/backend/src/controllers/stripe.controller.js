const Stripe = require('stripe');
const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

// Montos permitidos (unidad: MXN pesos)
const ALLOWED_AMOUNTS = [100, 250, 500, 1000, 2000];

async function createCheckoutSession(req, res) {
  try {
    const { amount } = req.body;
    const numeric = Number(amount);

    if (!numeric || !ALLOWED_AMOUNTS.includes(numeric)) {
      return res.status(400).json({ error: 'Monto inválido' });
    }

    // Convertir a centavos
    const amountCents = Math.round(numeric * 100);

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      line_items: [
        {
          price_data: {
            currency: 'mxn',
            product_data: {
              name: `Donativo CRIO $${numeric}`,
              metadata: { source: 'donativos-seccion' }
            },
            unit_amount: amountCents
          },
          quantity: 1
        }
      ],
      // URLs de éxito / cancelación
      success_url: `${process.env.FRONTEND_URL || 'http://localhost:5500'}/?donacion=exitosa`,
      cancel_url: `${process.env.FRONTEND_URL || 'http://localhost:5500'}/?donacion=cancelada`,
      metadata: {
        amount: numeric
      }
    });

    return res.json({ id: session.id });
  } catch (err) {
    console.error('Stripe createCheckoutSession error:', err);
    return res.status(500).json({ error: 'Error creando la sesión de pago' });
  }
}

module.exports = { createCheckoutSession };