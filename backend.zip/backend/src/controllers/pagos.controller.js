const { pool } = require('../config/db');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

const procesarPagoStripe = async (req, res) => {
  try {
    const { id_donacion, token, monto, email, descripcion } = req.body;

    if (!id_donacion || !monto) {
      return res.status(400).json({
        error: true,
        message: 'Datos de pago incompletos'
      });
    }

    const [donaciones] = await pool.query(
      'SELECT * FROM donaciones WHERE id_donacion = ?',
      [id_donacion]
    );

    if (donaciones.length === 0) {
      return res.status(404).json({
        error: true,
        message: 'Donación no encontrada'
      });
    }

    const donacion = donaciones[0];

    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(monto * 100),
      currency: 'mxn',
      payment_method_types: ['card'],
      receipt_email: email,
      description: descripcion || `Donación CRIO - ${donacion.nombre_donante || 'Anónimo'}`,
      metadata: {
        id_donacion: id_donacion.toString(),
        donante: donacion.nombre_donante || 'Anónimo'
      }
    });

    const [result] = await pool.query(
      `INSERT INTO pagos (referencia_ext, proveedor, estado, monto, id_donacion, datos_adicionales)
       VALUES (?, 'stripe', 'pendiente', ?, ?, ?)`,
      [
        paymentIntent.id,
        monto,
        id_donacion,
        JSON.stringify({
          client_secret: paymentIntent.client_secret,
          status: paymentIntent.status
        })
      ]
    );

    res.json({
      error: false,
      message: 'Pago iniciado correctamente',
      data: {
        id_pago: result.insertId,
        client_secret: paymentIntent.client_secret,
        payment_intent_id: paymentIntent.id
      }
    });

  } catch (error) {
    console.error('Error en procesarPagoStripe:', error);
    res.status(500).json({
      error: true,
      message: error.message || 'Error al procesar pago con Stripe'
    });
  }
};

const webhookStripe = async (req, res) => {
  const sig = req.headers['stripe-signature'];
  const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;

  let event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);
  } catch (err) {
    console.error('Error en webhook signature:', err.message);
    return res.status(400).send(`Webhook signature verification failed: ${err.message}`);
  }

  try {
    switch (event.type) {
      case 'payment_intent.succeeded':
        const paymentIntent = event.data.object;
        await handlePaymentSuccess(paymentIntent);
        break;

      case 'payment_intent.payment_failed':
        const failedPayment = event.data.object;
        await handlePaymentFailure(failedPayment);
        break;

      case 'charge.refunded':
        const refund = event.data.object;
        await handleRefund(refund);
        break;

      default:
        console.log(`Evento no manejado: ${event.type}`);
    }

    res.json({ received: true });
  } catch (error) {
    console.error('Error procesando webhook:', error);
    res.status(500).json({
      error: true,
      message: 'Error procesando webhook'
    });
  }
};

const handlePaymentSuccess = async (paymentIntent) => {
  try {
    const { id_donacion } = paymentIntent.metadata;
    
    await pool.query(
      'UPDATE pagos SET estado = "completado" WHERE referencia_ext = ?',
      [paymentIntent.id]
    );
    
    if (id_donacion) {
      await pool.query(
        'UPDATE donaciones SET estado = "completada" WHERE id_donacion = ?',
        [id_donacion]
      );
    }
    
    console.log(`✅ Pago completado: ${paymentIntent.id}`);
  } catch (error) {
    console.error('Error en handlePaymentSuccess:', error);
  }
};

const handlePaymentFailure = async (paymentIntent) => {
  try {
    await pool.query(
      'UPDATE pagos SET estado = "fallido" WHERE referencia_ext = ?',
      [paymentIntent.id]
    );
    
    const { id_donacion } = paymentIntent.metadata;
    if (id_donacion) {
      await pool.query(
        'UPDATE donaciones SET estado = "fallida" WHERE id_donacion = ?',
        [id_donacion]
      );
    }
    
    console.log(`❌ Pago fallido: ${paymentIntent.id}`);
  } catch (error) {
    console.error('Error en handlePaymentFailure:', error);
  }
};

const handleRefund = async (refund) => {
  try {
    const paymentIntentId = refund.payment_intent;
    
    await pool.query(
      'UPDATE pagos SET estado = "reembolsado" WHERE referencia_ext = ?',
      [paymentIntentId]
    );
    
    const [pagos] = await pool.query(
      'SELECT id_donacion FROM pagos WHERE referencia_ext = ?',
      [paymentIntentId]
    );
    
    if (pagos.length > 0) {
      await pool.query(
        'UPDATE donaciones SET estado = "reembolsada" WHERE id_donacion = ?',
        [pagos[0].id_donacion]
      );
    }
    
    console.log(`↩️ Pago reembolsado: ${paymentIntentId}`);
  } catch (error) {
    console.error('Error en handleRefund:', error);
  }
};

const confirmarPago = async (req, res) => {
  try {
    const { payment_intent_id } = req.body;
    
    const paymentIntent = await stripe.paymentIntents.retrieve(payment_intent_id);
    
    const [pagos] = await pool.query(
      'SELECT * FROM pagos WHERE referencia_ext = ?',
      [payment_intent_id]
    );
    
    if (pagos.length === 0) {
      return res.status(404).json({
        error: true,
        message: 'Pago no encontrado'
      });
    }
    
    res.json({
      error: false,
      data: {
        estado: paymentIntent.status,
        estado_db: pagos[0].estado,
        monto: paymentIntent.amount / 100
      }
    });
    
  } catch (error) {
    console.error('Error en confirmarPago:', error);
    res.status(500).json({
      error: true,
      message: error.message || 'Error al confirmar pago'
    });
  }
};

module.exports = { procesarPagoStripe, webhookStripe, confirmarPago };
