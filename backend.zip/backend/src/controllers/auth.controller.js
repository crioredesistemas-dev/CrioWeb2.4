const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { pool } = require('../config/db');

const login = async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({
        error: true,
        message: 'Usuario y contraseña son requeridos'
      });
    }

    const [users] = await pool.query(
      'SELECT * FROM usuarios_admin WHERE username = ? AND activo = TRUE',
      [username]
    );

    if (users.length === 0) {
      return res.status(401).json({
        error: true,
        message: 'Credenciales inválidas'
      });
    }

    const user = users[0];
    const validPassword = await bcrypt.compare(password, user.password);

    if (!validPassword) {
      return res.status(401).json({
        error: true,
        message: 'Credenciales inválidas'
      });
    }

    await pool.query(
      'UPDATE usuarios_admin SET ultimo_acceso = NOW() WHERE id_usuario = ?',
      [user.id_usuario]
    );

    const token = jwt.sign(
      {
        id_usuario: user.id_usuario,
        username: user.username,
        nombre: user.nombre,
        email: user.email,
        rol: user.rol
      },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '24h' }
    );

    res.json({
      error: false,
      message: 'Inicio de sesión exitoso',
      data: {
        token,
        user: {
          id_usuario: user.id_usuario,
          username: user.username,
          nombre: user.nombre,
          email: user.email,
          rol: user.rol
        }
      }
    });

  } catch (error) {
    console.error('Error en login:', error);
    res.status(500).json({
      error: true,
      message: 'Error interno del servidor'
    });
  }
};

const verifyToken = async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        error: true,
        message: 'Token requerido'
      });
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const [users] = await pool.query(
      'SELECT id_usuario, username, nombre, email, rol FROM usuarios_admin WHERE id_usuario = ? AND activo = TRUE',
      [decoded.id_usuario]
    );

    if (users.length === 0) {
      return res.status(401).json({
        error: true,
        message: 'Usuario no encontrado o inactivo'
      });
    }

    res.json({
      error: false,
      data: { user: users[0] }
    });

  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        error: true,
        message: 'Token expirado'
      });
    }
    
    return res.status(401).json({
      error: true,
      message: 'Token inválido'
    });
  }
};

module.exports = { login, verifyToken };
