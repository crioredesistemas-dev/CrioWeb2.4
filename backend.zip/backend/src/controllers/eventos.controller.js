const { pool } = require('../config/db');

const getAll = async (req, res) => {
  try {
    const { estado, limit = 10, offset = 0 } = req.query;
    
    let query = 'SELECT * FROM eventos WHERE 1=1';
    const params = [];
    
    if (estado) {
      query += ' AND estado = ?';
      params.push(estado);
    }
    
    query += ' ORDER BY fecha DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));
    
    const [eventos] = await pool.query(query, params);
    
    const [total] = await pool.query('SELECT COUNT(*) as total FROM eventos');
    
    res.json({
      error: false,
      data: {
        eventos,
        total: total[0].total,
        limit: parseInt(limit),
        offset: parseInt(offset)
      }
    });
  } catch (error) {
    console.error('Error en getAll eventos:', error);
    res.status(500).json({
      error: true,
      message: 'Error al obtener eventos'
    });
  }
};

const getById = async (req, res) => {
  try {
    const { id_evento } = req.params;
    
    const [eventos] = await pool.query(
      'SELECT * FROM eventos WHERE id_evento = ?',
      [id_evento]
    );
    
    if (eventos.length === 0) {
      return res.status(404).json({
        error: true,
        message: 'Evento no encontrado'
      });
    }
    
    res.json({
      error: false,
      data: eventos[0]
    });
  } catch (error) {
    console.error('Error en getById evento:', error);
    res.status(500).json({
      error: true,
      message: 'Error al obtener evento'
    });
  }
};

const create = async (req, res) => {
  try {
    console.log('INFO: create evento payload:', req.body);

    const {
      titulo,
      descripcion,
      fecha,
      fecha_fin,
      lugar,
      imagen,
      estado = 'activo',
      url_info = null
    } = req.body;
    
    if (!titulo || !fecha) {
      return res.status(400).json({
        error: true,
        message: 'Título y fecha son requeridos'
      });
    }
    
    const [result] = await pool.query(
      `INSERT INTO eventos 
       (titulo, descripcion, fecha, fecha_fin, lugar, imagen, estado, url_info, id_usuario) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        titulo,
        descripcion,
        fecha,
        fecha_fin,
        lugar,
        imagen,
        estado,
        url_info,
        req.user.id_usuario
      ]
    );

    // Intentar recuperar el registro creado para devolverlo al cliente
    const [rows] = await pool.query('SELECT * FROM eventos WHERE id_evento = ?', [result.insertId]);
    console.log('INFO: evento creado:', rows[0]);
    
    res.status(201).json({
      error: false,
      message: 'Evento creado exitosamente',
      data: rows[0]
    });
  } catch (error) {
    console.error('Error en create evento:', error);
    res.status(500).json({
      error: true,
      message: 'Error al crear evento: ' + error.message
    });
  }
};



























































































































































































































































































































































































































































































































































































































































































const update = async (req, res) => {
  try {
    const { id_evento } = req.params;
    const {
      titulo,
      descripcion,
      fecha,
      fecha_fin,
      lugar,
      imagen,
      estado,
      url_info
    } = req.body;
    
    const [existing] = await pool.query(
      'SELECT * FROM eventos WHERE id_evento = ?',
      [id_evento]
    );
    
    if (existing.length === 0) {
      return res.status(404).json({
        error: true,
        message: 'Evento no encontrado'
      });
    }
    
    // Si fecha_fin no se envía, mantener el valor existente
    const fechaFinValue = fecha_fin !== undefined ? fecha_fin : existing[0].fecha_fin;
    
    // Evitar sobreescritura accidental: solo actualizar url_info si viene con un valor no vacío
    const urlInfoValue = (typeof url_info !== 'undefined' && url_info !== null && String(url_info).trim() !== '') ? url_info : existing[0].url_info;

    console.log('INFO: update evento payload:', req.body);

    await pool.query(
      `UPDATE eventos SET 
       titulo = ?, descripcion = ?, fecha = ?, fecha_fin = ?, 
       lugar = ?, imagen = ?, estado = ?, url_info = ?, updated_at = NOW()
       WHERE id_evento = ?`,
      [titulo, descripcion, fecha, fechaFinValue, lugar, imagen, estado, urlInfoValue, id_evento]
    );

    // Recuperar registro actualizado y devolverlo
    const [updatedRows] = await pool.query('SELECT * FROM eventos WHERE id_evento = ?', [id_evento]);
    console.log('INFO: evento actualizado:', updatedRows[0]);

    res.json({
      error: false,
      message: 'Evento actualizado exitosamente',
      data: updatedRows[0]
    });

  } catch (error) {
    console.error('Error en update evento:', error);
    res.status(500).json({
      error: true,
      message: 'Error al actualizar evento: ' + error.message
    });
  }
};

const remove = async (req, res) => {
  try {
    const { id_evento } = req.params;
    
    const [existing] = await pool.query(
      'SELECT * FROM eventos WHERE id_evento = ?',
      [id_evento]
    );
    
    if (existing.length === 0) {
      return res.status(404).json({
        error: true,
        message: 'Evento no encontrado'
      });
    }
    
    await pool.query('DELETE FROM eventos WHERE id_evento = ?', [id_evento]);
    
    res.json({
      error: false,
      message: 'Evento eliminado exitosamente'
    });
  } catch (error) {
    console.error('Error en remove evento:', error);
    res.status(500).json({
      error: true,
      message: 'Error al eliminar evento'
    });
  }
};

module.exports = { getAll, getById, create, update, remove };
