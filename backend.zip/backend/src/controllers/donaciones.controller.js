const { pool } = require('../config/db');

const createDonacion = async (req, res) => {
    try {
        const {
            monto,
            metodo_pago = 'stripe',
            nombre_donante = 'Anónimo',
            email_donante,
            telefono = '',
            anonimo = false,
            recurrente = false,
            frecuencia = null,
            id_usuario = null
        } = req.body;

        if (!monto || !metodo_pago || !email_donante) {
            return res.status(400).json({
                error: true,
                message: 'Monto, método de pago y correo electrónico son requeridos'
            });
        }

        if (monto <= 0) {
            return res.status(400).json({
                error: true,
                message: 'El monto debe ser mayor a 0'
            });
        }

        const [result] = await pool.query(
            `INSERT INTO donaciones 
             (monto, metodo_pago, nombre_donante, email_donante, telefono, 
              anonimo, recurrente, frecuencia, id_usuario, estado) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pendiente')`,
            [
                monto, metodo_pago, nombre_donante, email_donante, telefono,
                anonimo, recurrente, frecuencia, id_usuario
            ]
        );

        // Crear registro en pagos para tracking
        await pool.query(
            `INSERT INTO pagos 
             (referencia_ext, proveedor, estado, monto, id_donacion, datos_adicionales)
             VALUES (?, 'stripe', 'pendiente', ?, ?, ?)`,
            [
                `pending_${Date.now()}`,
                monto,
                result.insertId,
                JSON.stringify({ stage: 'created', email: email_donante })
            ]
        );

        res.status(201).json({
            error: false,
            message: 'Donación registrada exitosamente',
            data: {
                id_donacion: result.insertId,
                monto,
                email: email_donante,
                estado: 'pendiente'
            }
        });

    } catch (error) {
        console.error('Error en createDonacion:', error);
        res.status(500).json({
            error: true,
            message: 'Error al registrar donación'
        });
    }
};

const getAllDonaciones = async (req, res) => {
  try {
    const { estado, fecha_inicio, fecha_fin, limit = 50, offset = 0 } = req.query;
    
    let query = 'SELECT * FROM donaciones WHERE 1=1';
    const params = [];
    
    if (estado) {
      query += ' AND estado = ?';
      params.push(estado);
    }
    
    if (fecha_inicio) {
      query += ' AND DATE(fecha) >= ?';
      params.push(fecha_inicio);
    }
    
    if (fecha_fin) {
      query += ' AND DATE(fecha) <= ?';
      params.push(fecha_fin);
    }
    
    query += ' ORDER BY fecha DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));
    
    const [donaciones] = await pool.query(query, params);
    
    const [total] = await pool.query('SELECT COUNT(*) as total FROM donaciones');
    
    res.json({
      error: false,
      data: {
        donaciones,
        total: total[0].total
      }
    });

  } catch (error) {
    console.error('Error en getAllDonaciones:', error);
    res.status(500).json({
      error: true,
      message: 'Error al obtener donaciones'
    });
  }
};

const getDonacionById = async (req, res) => {
  try {
    const { id } = req.params;
    
    const [donaciones] = await pool.query(
      `SELECT d.*, p.referencia_ext, p.proveedor, p.estado as estado_pago
       FROM donaciones d
       LEFT JOIN pagos p ON d.id_donacion = p.id_donacion
       WHERE d.id_donacion = ?`,
      [id]
    );
    
    if (donaciones.length === 0) {
      return res.status(404).json({
        error: true,
        message: 'Donación no encontrada'
      });
    }
    
    res.json({
      error: false,
      data: donaciones[0]
    });

  } catch (error) {
    console.error('Error en getDonacionById:', error);
    res.status(500).json({
      error: true,
      message: 'Error al obtener donación'
    });
  }
};

module.exports = { createDonacion, getAllDonaciones, getDonacionById };
