// Script para poblar datos de ejemplo
const { pool } = require('../config/db');

const eventos = [
    {
        titulo: "Caminata por la Rehabilitación 2024",
        descripcion: "Acompáñanos en nuestra caminata anual para promover la rehabilitación integral y la inclusión social de personas con discapacidad. Recorrido de 5km por el centro de Orizaba.",
        fecha: "2024-11-15 08:00:00",
        fecha_fin: "2024-11-15 12:00:00",
        lugar: "Parque Castillo, Orizaba, Ver.",
        imagen: "/imagenes/eventos/caminata.jpg",
        estado: "activo",
        id_usuario: 1
    },
    {
        titulo: "Taller de Terapia Física en Casa",
        descripcion: "Aprende técnicas básicas de terapia física para el cuidado y rehabilitación en casa. Dirigido a familiares y cuidadores de personas con discapacidad.",
        fecha: "2024-12-01 10:00:00",
        fecha_fin: "2024-12-01 14:00:00",
        lugar: "CRIO - Salón Principal, Orizaba",
        imagen: "/imagenes/eventos/taller.jpg",
        estado: "activo",
        id_usuario: 1
    },
    {
        titulo: "Campaña de Donación de Sangre",
        descripcion: "Colabora con nuestra campaña de donación de sangre. Tu ayuda salva vidas y permite continuar con los tratamientos de rehabilitación.",
        fecha: "2024-12-10 09:00:00",
        fecha_fin: "2024-12-10 15:00:00",
        lugar: "Instalaciones CRIO, Orizaba",
        imagen: "/imagenes/eventos/sangre.jpg",
        estado: "activo",
        id_usuario: 1
    },
    {
        titulo: "Día Internacional de las Personas con Discapacidad",
        descripcion: "Celebración con actividades culturales, conferencias y demostraciones de terapias. Evento abierto al público general.",
        fecha: "2024-12-03 09:00:00",
        fecha_fin: "2024-12-03 18:00:00",
        lugar: "CRIO - Jardín Principal",
        imagen: "/imagenes/eventos/discapacidad.jpg",
        estado: "activo",
        id_usuario: 1
    },
    {
        titulo: "Jornada de Evaluaciones Gratuitas",
        descripcion: "Jornada de evaluaciones neurológicas y físicas gratuitas para niños y adultos. Cupo limitado, agenda tu cita.",
        fecha: "2024-12-15 08:00:00",
        fecha_fin: "2024-12-15 14:00:00",
        lugar: "CRIO - Consultorios",
        imagen: "/imagenes/eventos/evaluaciones.jpg",
        estado: "activo",
        id_usuario: 1
    }
];

async function seed() {
    try {
        console.log('🌱 Iniciando siembra de datos...');
        
        // Verificar si ya hay eventos
        const [existing] = await pool.query('SELECT COUNT(*) as count FROM eventos');
        
        if (existing[0].count > 0) {
            console.log('⚠️ Ya existen eventos en la base de datos. ¿Desea eliminar y recrear? (s/N)');
            // En implementación real, preguntar o limpiar
            return;
        }
        
        for (const evento of eventos) {
            await pool.query(
                `INSERT INTO eventos 
                 (titulo, descripcion, fecha, fecha_fin, lugar, imagen, estado, id_usuario) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                [
                    evento.titulo,
                    evento.descripcion,
                    evento.fecha,
                    evento.fecha_fin,
                    evento.lugar,
                    evento.imagen,
                    evento.estado,
                    evento.id_usuario
                ]
            );
            console.log(`✅ Evento creado: ${evento.titulo}`);
        }
        
        console.log('\n✨ Datos de ejemplo insertados correctamente!');
        console.log(`📊 Total eventos: ${eventos.length}`);
        
    } catch (error) {
        console.error('❌ Error en seed:', error);
        process.exit(1);
    } finally {
        await pool.end();
    }
}

seed();
