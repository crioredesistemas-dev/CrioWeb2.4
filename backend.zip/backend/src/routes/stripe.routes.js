const express = require('express');
const router = express.Router();
const { createCheckoutSession } = require('../controllers/stripe.controller');

// body parser middleware already applied in server.js; include json middleware here for safety
router.post('/create-checkout-session', express.json(), createCheckoutSession);

module.exports = router;
