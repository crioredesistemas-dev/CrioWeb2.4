const express = require('express');
const router = express.Router();
const { authMiddleware, adminMiddleware } = require('../middleware/auth.middleware');
const { createDonacion, getAllDonaciones, getDonacionById } = require('../controllers/donaciones.controller');

router.post('/', createDonacion);
router.get('/', authMiddleware, adminMiddleware, getAllDonaciones);
router.get('/:id', authMiddleware, adminMiddleware, getDonacionById);

module.exports = router;
