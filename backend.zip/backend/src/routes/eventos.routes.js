const express = require('express');
const router = express.Router();
const { authMiddleware, adminMiddleware } = require('../middleware/auth.middleware');
const { getAll, getById, create, update, remove } = require('../controllers/eventos.controller');

router.get('/', getAll);
router.get('/:id_evento', getById);

router.post('/', authMiddleware, adminMiddleware, create);
router.put('/:id_evento', authMiddleware, adminMiddleware, update);
router.delete('/:id_evento', authMiddleware, adminMiddleware, remove);

module.exports = router;
