const express = require('express');
const router = express.Router();
const { procesarPagoStripe, webhookStripe, confirmarPago } = require('../controllers/pagos.controller');

router.post('/procesar', procesarPagoStripe);
router.post('/webhook', express.raw({ type: 'application/json' }), webhookStripe);
router.post('/confirmar', confirmarPago);

module.exports = router;
